
import axios from 'axios';

export default async (req, res) => {
  const { cityName } = req.query;
  try {
    const response = await axios.get('https://api.locationiq.com/v1/autocomplete.php', {
      params: {
        key: process.env.LOCATIONIQ_API_KEY,
        q: cityName,
        normalizecity: 1
      }
    });
    console.log("API response data:", response.data); // Log the response data to the console
    res.status(200).json({ isValid: response.data.length > 0 });
  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({ error: 'Failed to validate city' });
  }
};

