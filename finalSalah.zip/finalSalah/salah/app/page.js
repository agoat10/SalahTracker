"use client";

//imports
import { useState } from 'react';
import axios from 'axios';
import styles from '../app/page.module.css';

export default function Home() {
  //state hooks for handling form inputs and data
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');
  const [salahTimes, setSalahTimes] = useState(null);

  //converts 24 hour clock to 12 hour clock
  function convertTo12Hour(timeString) {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours, 10);
    const suffix = hour >= 12 ? "PM" : "AM";
    const convertedHour = ((hour + 11) % 12 + 1);
    return `${convertedHour}:${minutes} ${suffix}`;
  };

  //form for checking city and country
  const handleFormSubmit = async (e) => {
  e.preventDefault();
  if (!city || !country) {
    alert('Please enter both city and country names'); //pop-up if form isn't filled out
    return;
  }
  fetchSalahTimes(); //calls function to fetch prayer times from api
};

  //validates the city name using another api
  const validateCity = async (cityName) => {
    try {
      const res = await fetch(`/api/validateCity?cityName=${encodeURIComponent(cityName)}`);
      const data = await res.json();
      return data.isValid;
    } catch (error) {
      console.error('Failed to fetch or parse city validation:', error);
      return false; 
    }
  };

  //fetches the prayer time from the api
  const fetchSalahTimes = async () => {
    if (!city) {
      alert('Please enter a city name');
      return;
    }
  
    try {
      //fetch information using the api
      const response = await axios.get(`https://api.aladhan.com/v1/timingsByCity`, {
        params: {
          city: city,
          country: country,
          method: 2, //ISNA calculation method
        }
      });
  
      //logging the API response to verify data
      console.log("API Response:", response.data);
  
      //extracting prayer times from the API response
      const timings = response.data.data.timings;
      const filteredTimings = {
        //fetching each prayer time, converted
        Fajr: convertTo12Hour(timings.Fajr),
        Dhuhr: convertTo12Hour(timings.Dhuhr),
        Asr: convertTo12Hour(timings.Asr),
        Maghrib: convertTo12Hour(timings.Maghrib),
        Isha: convertTo12Hour(timings.Isha)
      };
  
      //setting the state with the converted prayer times
      setSalahTimes(filteredTimings);
    } catch (error) {
      console.error('Error fetching Salah times:', error);
      alert('Failed to fetch Salah times, please check your network or try again later.');
      setSalahTimes(null);
    }
  };

  //render function for the component
  return (
    <div className={styles.container}>
      <h1>Salah Time Tracker</h1> {/*title*/}
      <div className={styles.contentBox}>
        <div className={styles.formContainer}>
          <form onSubmit={handleFormSubmit}>
            <input 
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="Enter city"
              className={styles.input}
            />
             <input 
              type="text"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              placeholder="Enter country"
              className={styles.input}
            />
            <button type="submit" className={styles.button}>Get Salah Times!</button> {/*action button*/}
          </form>
        </div>
        {salahTimes && (
          <ul className={styles.list}> {/* Updated to use class */}
            {Object.entries(salahTimes).map(([prayer, time]) => (
              <li key={prayer} className={styles.listItem}>{`${prayer}: ${time}`}</li>
            ))}
          </ul>
        )}
      </div>
      <div className={styles.h3}>
      <h3> The Prophet Muhammad ﷺ said:
      Indeed the first deed by which a servant will be called to
      account on the Day of Resurrection is his Salat. If it is complete,
      he is successful and saved, but if it is defective, he has failed and lost…
      (Jami` at-Tirmidhi 413) </h3>
      </div>
    </div>
  );
}
